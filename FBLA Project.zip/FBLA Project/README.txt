Project title: FBLA quiz
This program is created by Jacky Ji.
This is a short 5 question FBLA quiz with a database of 50 questions.
Inside the database, there are 10 true and false questions,
17 multiple-choice questions,
10 drop-down question,
and 13 fill in the blank questions.
The questions are randomly selected between the 4 different types of questions.
On each quiz run, the same question should not show up more than once.

Citations
Questions are retrieved from
https://www.tangischools.org/cms/lib/LA01001731/Centricity/Domain/2671/FBLA%20Principles%20and%20Procedures.pdf
https://www.tangischools.org/cms/lib/LA01001731/Centricity/Domain/2671/FBLA%20Principles%20and%20Procedures%20old.pdf
https://articles.bplans.com/business-term-glossary/
https://www.fbla-pbl.org/about/
https://bryantschoolsfbla.weebly.com/facts-about-fbla.html
https://www.deca.org/wp-content/uploads/2017/10/Col_Mkt_Exam.pdf

Image is retrieved from
https://www.fbla-pbl.org/cmh/logos-images/