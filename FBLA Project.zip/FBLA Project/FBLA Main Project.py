from tkinter import *
from PIL import ImageTk, Image
import random

# Colors and font size
qFont = 18
blue = '#99d4e9'
wrapWidth = 500

root = Tk()
frame = Frame(root)
frame.pack(side="top", expand=True, fill="both")
frame.config(bg = blue)

# Sets the size of the window
menuFrame = "520x550"
root.title("FBLA Quiz")
root.geometry(menuFrame)

score = 0
currentQ = 0
randQType = 0
randQ = 0

# Stores all the questions asked and the users answers
qAsked = [[], [], [], []]
userAnswer = [[], [], [], []]

# The answers available for selection
MCAnswers = []
DDAnswers = []
# The questions and the answer key for each section
# True and false
TFQuestions = []
TFAnswerKey = []
# Multiple choice
MCQuestions = []
MCAnswerKey = []
# Drop down
DDQuestions = []
DDAnswerKey = []
# Fill in the blank
FBQuestions = []
FBAnswerKey = []

# Used to retrieve the different question selections for multiple choice and drop down
# answerNum is used to check the if the current line in the txt file is a question or a possible answer
def OpenAnswers(txtFileName, answerNum, answerList):
    with open("Questions/" + txtFileName) as a:
        counter = 0
        for line in a:
            if counter % answerNum != 0:
                answerList.append(line.rstrip())
            counter += 1

OpenAnswers('MC_Questions.txt', 5, MCAnswers)
OpenAnswers('Drop_Down_Questions.txt', 5, DDAnswers)

# Used to retrieve the questions and the answer key for each question type
def OpenAnswerKey(txtFileName, answerNum, questionList, answerList):
    with open("Questions/" + txtFileName) as a:
        counter = 0
        for line in a:
            if counter % answerNum == 0:
                temp = line.rstrip().split(",")
                questionList.append(temp[0])
                answerList.append(temp[1].capitalize())
            counter += 1

OpenAnswerKey('MC_Questions.txt', 5, MCQuestions, MCAnswerKey)
OpenAnswerKey('TF_Questions.txt', 1, TFQuestions, TFAnswerKey)
OpenAnswerKey('Drop_Down_Questions.txt', 5, DDQuestions, DDAnswerKey)
OpenAnswerKey('Fill_Blank_Questions.txt', 1, FBQuestions, FBAnswerKey)

# Clears all the widgets on the screen
def ClearWindow():
    for widget in frame.winfo_children():
        widget.destroy()

# Opens a photo from the local Images folder
def OpenImage(ImgName, x, y):
    img = Image.open("Images/" + ImgName)
    img = img.resize((x, y), Image.ANTIALIAS)
    img = ImageTk.PhotoImage(img)
    panel = Label(frame, image=img)
    panel.image = img
    panel.pack()

# This is a status bar used to indicate which question the user is currently on
def StatusBar():
    curtQText = "Question " + str(currentQ + 1) + " out of 5"
    currentQuestion = Label(frame, text=curtQText, font=("Consolas", 14))
    currentQuestion.pack(side=TOP, anchor=NW)

# This creates the main menu
def Menu():
    ClearWindow()
    # Rests the window size after reviewing answers
    root.geometry(menuFrame)
    global score
    global currentQ
    global qAsked
    global userAnswer
    # Reset variables
    score = 0
    currentQ = 0
    qAsked = [[], [], [], []]
    userAnswer = [[], [], [], []]
    title = Label(frame, text="Welcome to my FBLA quiz", font=("Consolas bold", 25), bg = blue, fg= "white")
    title.pack(pady=(60, 25))
    OpenImage('FBLA_Logo.png', 150, 150)
    description = Label(frame, text="are you ready?", font=("Consolas", 16), bg = blue, fg= "white")
    description.pack(pady=(20, 20))
    startButtom = Button(frame, text="Start!",
                         font=("Consolas", 16), height=2, width=20, fg="red",
                         command=ChooseTypeOfQuestion)
    startButtom.pack()

# Chooses a random question from the database
def ChooseTypeOfQuestion():
    global currentQ
    global randQType
    ClearWindow()
    StatusBar()

    currentQ += 1
    randQType = random.randint(0, 3)

    if randQType == 0:
        TF()
    elif randQType == 1:
        MC()
    elif randQType == 2:
        DropDown()
    elif randQType == 3:
        FillBlank()

# Creates the finished/result screen
def FinishedQuiz():
    ClearWindow()
    finishedText = Label(frame, text="Congratulations on finishing the quiz!", font=("Consolas", 20), bg = blue, fg= "white")
    scoreCalc = "Your score is: " + str(score) + "/5"
    scoreText = Label(frame, text=scoreCalc, font=("Consolas", 20), bg = blue, fg= "white")
    menuButon = Button(frame, text="Menu",
                       font=("Consolas", 16), height=2, width=20, fg="green",
                       command=Menu)
    reviewButton = Button(frame, text="Check your answers?",
                          font=("Consolas", 16), height=2, width=20, fg="green",
                          command=ReviewAnswers)
    finishedText.config(wraplength=wrapWidth)
    finishedText.pack(pady=(80, 10))
    scoreText.pack(pady=(20, 10))
    menuButon.pack(pady=(20, 10))
    reviewButton.pack(pady=(20, 10))

# Review the answers that the user got right or wrong
def ReviewAnswers():
    ClearWindow()
    root.geometry("")
    # Counter used for tracking the type of question
    category = 0
    # Counter used for tracking which answer to display
    answerCounter = 0
    title = Label(frame, text="Review", font=("Consolas bold", 18), bg=blue, fg="white")
    title.pack(pady=(20, 0))
    # Loops through the question types
    for i in qAsked:
        # Check if questions were asked in a question type
        if len(i) == 0:
            category += 1
            continue

        # Display the questions asked, user answer, and correct answer
        def PrintAnswer(questionArray, answerKeyArray):
            userAnswerText = "Your answer was " + userAnswer[category][answerCounter]
            question = Label(frame, text=questionArray[c], font=("Consolas", 14), bg = blue, fg= "white")
            userInputAns = Label(frame, text=userAnswerText, font=("Consolas",14), bg = blue, fg= "white")
            question.config(wraplength=wrapWidth)
            question.pack(pady=(15, 0), padx=(10, 10))
            userInputAns.pack()
            # Checks if a correct answer is needed to be displayed
            if userAnswer[category][answerCounter] == answerKeyArray[c]:
                text = "Congratulations you got it right!"
                color = "green"
            else:
                text = "The correct answer is " + answerKeyArray[c]
                color = "#d5212e"
            feedback = Label(frame, text=text, font=("Consolas", 14), fg=color, bg = blue)
            feedback.pack(padx=(10, 10))

        # Loops through each question asked in a question type
        for c in i:
            if category == 0:
                PrintAnswer(TFQuestions, TFAnswerKey)
            elif category == 1:
                PrintAnswer(MCQuestions, MCAnswerKey)
            elif category == 2:
                PrintAnswer(DDQuestions, DDAnswerKey)
            elif category == 3:
                PrintAnswer(FBQuestions, FBAnswerKey)
            answerCounter += 1
        category += 1
        answerCounter = 0
    menuButon = Button(frame, text="Menu",
                       font=("Consolas", 16), height=2, width=20, fg="red",
                       command=Menu)
    menuButon.pack(pady=(20, 20))

# Checks if the user got the question correct
def CheckAnswer(typeQ, question, answer):
    global score 
    answer = answer.capitalize()
    userAnswer[typeQ].append(answer)
    if typeQ == 0:
        if answer == TFAnswerKey[question]:
            score += 1
    elif typeQ == 1:
        if answer == MCAnswerKey[question]:
            score += 1
    elif typeQ == 2:
        if answer == DDAnswerKey[question]:
            score += 1
    elif typeQ == 3:
        if answer == FBAnswerKey[question]:
            score += 1

    if currentQ == 5:
        FinishedQuiz()
    else:
        ChooseTypeOfQuestion()

# Generates a brand new question and saves it
def SaveQuestionAsked(indexNum, questionArray):
    validQuestion = False
    global qAsked
    randQ = 0
    while validQuestion == False:
        randQ = random.randint(0, len(questionArray) - 1)
        for i in qAsked[indexNum]:
            if i == randQ:
                break
        else:
            validQuestion = True

    qAsked[indexNum].append(randQ)
    return randQ

# True and false section
def TF():
    indexNum = 0
    randQ = SaveQuestionAsked(indexNum, TFQuestions)
    questionText = Label(frame, text=TFQuestions[randQ], font=("Consolas", qFont), bg = blue, fg= "white")
    trueButton = Button(frame, text="True",
                        font=("Consolas", 16), height=2, width=20, fg="green",
                        command=lambda: CheckAnswer(0, randQ, "true"))
    falseButton = Button(frame, text="False",
                         font=("Consolas", 16), height=2, width=20, fg="red",
                         command=lambda: CheckAnswer(0, randQ, "false"))
    questionText.config(wraplength=wrapWidth)
    questionText.pack(pady=(30, 10), padx=(10, 10))
    trueButton.pack(pady=(20, 10))
    falseButton.pack(pady=(20, 10))

# Multiple choice section
def MC():
    indexNum = 1
    randQ = SaveQuestionAsked(indexNum, MCQuestions)
    questionText = Label(frame, text=MCQuestions[randQ], font=("Consolas", qFont), bg = blue, fg= "white")

    option1 = Button(frame, text=MCAnswers[randQ * 4],
                     font=("Consolas", 12), height=2, width=26,
                     command=lambda: CheckAnswer(1, randQ, MCAnswers[randQ * 4]))
    option2 = Button(frame, text=MCAnswers[randQ * 4 + 1],
                     font=("Consolas", 12), height=2, width=26,
                     command=lambda: CheckAnswer(1, randQ, MCAnswers[randQ * 4 + 1]))
    option3 = Button(frame, text=MCAnswers[randQ * 4 + 2],
                     font=("Consolas", 12), height=2, width=26,
                     command=lambda: CheckAnswer(1, randQ, MCAnswers[randQ * 4 + 2]))
    option4 = Button(frame, text=MCAnswers[randQ * 4 + 3],
                     font=("Consolas", 12), height=2, width=26,
                     command=lambda: CheckAnswer(1, randQ, MCAnswers[randQ * 4 + 3]))
    questionText.config(wraplength=wrapWidth)
    questionText.pack(pady=(30, 10))
    option1.pack(pady=(20, 10))
    option2.pack(pady=(20, 10))
    option3.pack(pady=(20, 10))
    option4.pack(pady=(20, 10))

# Drop down section
def DropDown():
    indexNum = 2
    randQ = SaveQuestionAsked(indexNum, DDQuestions)
    selection = StringVar()
    selection.set(DDAnswers[randQ * 4])
    questionText = Label(frame, text=DDQuestions[randQ], font=("Consolas", qFont), bg = blue, fg= "white")
    dropDown = OptionMenu(frame, selection,
                          DDAnswers[randQ * 4],
                          DDAnswers[randQ * 4 + 1],
                          DDAnswers[randQ * 4 + 2],
                          DDAnswers[randQ * 4 + 3])
    dropDown.config(font=("Consolas", 16))
    items = frame.nametowidget(dropDown.menuname)
    items.config(font=("Consolas", 16))
    confirmButton = Button(frame, text="Confirm",
                           font=("Consolas", 16), height=2, width=20, fg="green",
                           command=lambda: CheckAnswer(2, randQ, selection.get()))
    questionText.config(wraplength=wrapWidth)
    questionText.pack(pady=(30, 10))
    dropDown.pack(pady=(20, 10))
    confirmButton.pack(pady=(150, 10))

# Fill in the blank section
def FillBlank():
    indexNum = 3
    randQ = SaveQuestionAsked(indexNum, FBQuestions)
    questionText = Label(frame, text=FBQuestions[randQ], font=("Consolas", qFont), bg = blue, fg= "white")
    inputField = Entry(frame, width=20, borderwidth=5)

    confirmButton = Button(frame, text="Confirm",
                           font=("Consolas", 16), height=2, width=20, fg="green",
                           command=lambda: CheckAnswer(3, randQ, inputField.get()))

    inputField.config(font=("Consolas", 14))
    questionText.config(wraplength=wrapWidth)
    questionText.pack(pady=(30, 10))
    inputField.pack(pady=(20, 10))
    confirmButton.pack(pady=(20, 10))

# Run the menu
Menu()

root.mainloop()
